<template>
  <v-app-bar app color="white" height="100">
    <v-avatar class="mr-3" color="grey lighten-5" size="70">
      <v-img contain max-height="70%" src="logo.jpeg"></v-img>
    </v-avatar>

    <v-toolbar-title class="font-weight-black headline">Account & consulting</v-toolbar-title>

    <v-spacer></v-spacer>

    <v-btn depressed text small class="mr-4 d-none d-sm-none d-md-flex" router to="/">Home</v-btn>
    <v-btn depressed text small class="mr-4  d-none d-sm-none d-md-flex" router to="/VisionMisionComponent">Above</v-btn>
    <v-btn depressed text small class="mr-4  d-none d-sm-none d-md-flex" router to="/CareerBanner">Job</v-btn>
    <v-btn depressed text small class="mr-4  d-none d-sm-none d-md-flex" router to="/Team">Our Team</v-btn>
    <v-btn depressed text small class="mr-4  d-none d-sm-none d-md-flex" router to="/Contents">Contact</v-btn>

    <v-btn class="ma-2 d-none d-sm-none d-md-flex" tile large color="teal" icon router to="/Login">
      <i class="fas fa-user-lock"></i>
    </v-btn>
    

   
      <v-app-bar-nav-icon color="primary" dark @click.stop="dialog = true" class="d-none d-sm-flex d-md-none"></v-app-bar-nav-icon>
      <v-dialog v-model="dialog" max-width="290">
        <v-card>
          <v-card-title class="headline">Use Google's location service?</v-card-title>

          <v-card-text>Let Google help apps determine location. This means sending anonymous location data to Google, even when no apps are running.</v-card-text>

          <v-card-actions>
            <v-spacer></v-spacer>

            <v-btn color="green darken-1" text @click="dialog = false">Disagree</v-btn>

            <v-btn color="green darken-1" text @click="dialog = false">Agree</v-btn>
          </v-card-actions>
        </v-card>
      </v-dialog>
   
  </v-app-bar>
</template>

<script>
export default {
  data() {
    return {
      dialog: false
    };
  }
};
</script>