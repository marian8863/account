<template>
  <section id="Member" class="grey lighten-3">

  
    <v-container >
        <h2 class="display-1 font-weight-bold mb-3 text-left">Accountor Online service packages: outsource everything or do as much as you want</h2>
    
            <div class="title font-weight-light mb-5 text-left ml-12">Is it enough to just outsource accounting? Or do you choose complete carefreeness and entrust the entire financial management to us? <span class="font-weight-bold">Decide yourself.</span> </div>
            <div class="title font-weight-light mb-5 text-left ml-12">Accountor has a service package for all stages and needs of the company's life cycle.</div>
    </v-container>
  </section>
</template>