<template>
  <section id="Member">
   
    <v-container>
      <v-row>
        <v-col class="col-12 col-sm-12 col-md-4">
          <v-card class="mx-auto" :elevation="0">
            <v-row>
              <v-col class="text-center">
                <v-avatar color="orange" size="150">
                  <span class="white--text" style="font-size:120px">1</span>
                </v-avatar>
              </v-col>
            </v-row>

            <v-card-subtitle
              class="font-weight-black mb-4 text-uppercase text-center"
            >Let us take care of everything</v-card-subtitle>

            <v-card-text>
              <div
                class="title font-weight-light mb-5 text-left"
              >When you prefer to spend your time entirely running your company’s core business, let us take care of everything.</div>
            </v-card-text>
          </v-card>
        </v-col>
        <v-col class="col-12 col-sm-12 col-md-4">
          <v-card class="mx-auto" :elevation="0">
            <v-row>
              <v-col class="text-center">
                <v-avatar color="red" size="150">
                  <span class="white--text" style="font-size:120px">2</span>
                </v-avatar>
              </v-col>
            </v-row>

            <v-card-subtitle
              class="font-weight-black mb-4 text-uppercase text-center"
            >Divide the work of financial administration in half</v-card-subtitle>

            <v-card-text>
              <div
                class="title font-weight-light mb-5 text-left"
              >Give us accounting, auditing and paying invoices, tracking and allocating invoices yourself, and auditing overdue invoices.</div>
            </v-card-text>
          </v-card>
        </v-col>
        <v-col class="col-12 col-sm-12 col-md-4">
          <v-card class="mx-auto" :elevation="0">
            <v-row>
              <v-col class="text-center">
                <v-avatar color="blue" size="150">
                  <span class="white--text" style="font-size:120px">3</span>
                </v-avatar>
              </v-col>
            </v-row>

            <v-card-subtitle
              class="font-weight-black mb-4 text-uppercase text-center"
            >Just give us what you need</v-card-subtitle>

            <v-card-text>
              <div
                class="title font-weight-light mb-5 text-left"
              >Entrust us with accounting, accounting for purchase and travel invoices, and accounting authority declarations.</div>
            </v-card-text>
          </v-card>
        </v-col>
      </v-row>
    </v-container>
     <hr>
  </section>
</template>